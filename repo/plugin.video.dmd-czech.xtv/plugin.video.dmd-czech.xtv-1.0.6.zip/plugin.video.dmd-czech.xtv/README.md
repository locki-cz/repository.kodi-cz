# plugin.video.czech-xtv

Video doplněk do [Kodi](http://www.kodi.tv/) pro přehrávání videí z [XTV.cz](https://xtv.cz/).
