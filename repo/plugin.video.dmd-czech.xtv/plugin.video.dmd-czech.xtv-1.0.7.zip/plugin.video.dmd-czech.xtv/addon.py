# -*- coding: utf-8 -*-
import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib
import urllib2
import re
import time
import datetime
import json
from bs4 import BeautifulSoup
import requests

_UserAgent_ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, lkodiazor Gecko) Chrome/52.0.2743.116 Safari/537.36'

_baseurl_ = 'https://xtv.cz/'
_mediaurl_ = 'https://s.xtv.cz/'
_dataurl_ = 'https://xtv.cz/loadmore/archive/0/3000'

_addon_ = xbmcaddon.Addon('plugin.video.dmd-czech.xtv')
_scriptname_ = _addon_.getAddonInfo('name')
_icon_ = xbmc.translatePath(os.path.join(_addon_.getAddonInfo('path'), 'icon.png'))
        
def log(msg, level=xbmc.LOGDEBUG):
    if type(msg).__name__ == 'unicode':
        msg = msg.encode('utf-8')
    xbmc.log("[%s] %s" % (_scriptname_, msg.__str__()), level)

def logDbg(msg):
	log(msg,level=xbmc.LOGDEBUG)

def logErr(msg):
	log(msg,level=xbmc.LOGERROR)

def fetchUrl(url):
    logDbg("fetchUrl " + url)
    httpdata = ''
    try:
        request = urllib2.Request(url, headers={'User-Agent': _UserAgent_,})
        resp = urllib2.urlopen(request)
        httpdata = resp.read()
    except:
        httpdata = None
    finally:
        resp.close() 
    return httpdata

def listShows():
    soup = BeautifulSoup(fetchUrl(_baseurl_+'porady'), 'html.parser')
    porady = soup.find_all('div', class_='porady-bg')
    
    for porad in porady:
        if porad.get('id'):
            name = re.search('<!--h2>(.+)<\/h2-->', str(porad)).group(1)
            thumb = porad.find('div', class_='porad-cover lazy')['data-src']    
            addDir(name, porad.get('id'), thumb, 1)

def listItems():
    xbmcplugin.setContent(addonHandle, 'episodes')
    data = json.loads(fetchUrl(_dataurl_))

    if (not data):
        return

    for item in data['data']:
        date = datetime.datetime(*(time.strptime(item['published_at'], "%Y-%m-%d %H:%M:%S")[:6])).strftime("%Y-%m-%d")
        title = item['perex']
        description = item['title']
        dur = item['video_duration']
        image = _mediaurl_+"i/cover/640/"+item['cover']
        
        li = xbmcgui.ListItem(title)
        
        if dur and ':' in dur:
            l = dur.strip().split(':')
            duration = 0
            for pos, value in enumerate(l[::-1]):
            	duration += int(value) * 60 ** pos
            li.addStreamInfo('video', {'duration': duration})
        li.setThumbnailImage(image)
        li.setIconImage(_icon_)
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'mediatype': 'episode', 'title': title, 'plot': description, 'premiered': date})
        li.setProperty('fanart_image', image)
        
        u=sys.argv[0]+'?mode=10&url='+urllib.quote_plus(item['uri'].encode('utf-8'))
        if item['porad'] == url and item['active'] == "1": 
            xbmcplugin.addDirectoryItem(handle=addonHandle, url=u, listitem=li, isFolder=False)

def videoLink(url): 
    soup = BeautifulSoup(fetchUrl(_baseurl_+'archiv/'+url), 'html.parser')
    
    title = soup.find("meta", property="og:description")
    desc = soup.find("meta", property="og:title")
    videos = soup.find_all("source", {"type":"video/mp4"})
       
    for content in videos:
        stream_url=content['src']
        
    liz = xbmcgui.ListItem(label=title["content"])
    liz = xbmcgui.ListItem(path=stream_url)
    liz.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle=addonHandle, succeeded=True, listitem=liz)
    
def addDir(name,url,iconimage, mode):
    logDbg("addDir(): '"+name+"' url='"+url+"' icon='"+iconimage+"' mode='"+str(mode)+"'")
    u=sys.argv[0]+"?url="+urllib.quote_plus(url.encode('utf-8'))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name.encode('utf-8'))
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)   
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    ok=xbmcplugin.addDirectoryItem(handle=addonHandle,url=u,listitem=liz,isFolder=True)
    return ok
    
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

addonHandle=int(sys.argv[1])
params=get_params()
url=None
name=None
thumb=None
mode=None

try:
    url=urllib.unquote_plus(params["url"])
except:
    pass

try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
    
try:
    mode=int(params["mode"])
except:
    pass

if mode==None or url==None or len(url)<1:
    listShows()
    logDbg("listShows()")
elif mode==1:
    listItems()
    logDbg("listItems()")
elif mode==10:
    videoLink(url)
    logDbg("videoLink()")
    
xbmcplugin.endOfDirectory(addonHandle)
