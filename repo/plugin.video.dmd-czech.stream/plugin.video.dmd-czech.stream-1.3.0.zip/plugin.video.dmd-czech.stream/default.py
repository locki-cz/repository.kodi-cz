# -*- coding: utf-8 -*-
import os
import urllib
import urllib2
import xbmcplugin
import xbmcgui
import xbmcaddon
import json
from datetime import datetime

__apiurl__ = 'https://api.televizeseznam.cz/graphql'
_UserAgent_ = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'
addon = xbmcaddon.Addon('plugin.video.dmd-czech.stream')
profile = xbmc.translatePath(addon.getAddonInfo('profile'))
__settings__ = xbmcaddon.Addon(id='plugin.video.dmd-czech.stream')
home = xbmc.translatePath(__settings__.getAddonInfo('path')).decode("utf-8")
icon = os.path.join( home, 'icon.png' ) 
nexticon = os.path.join( home, 'nextpage.png' )
fanart = os.path.join( home, 'fanart.jpg' )
scriptname = addon.getAddonInfo('name')
quality_index = int(addon.getSetting('quality'))
quality_settings = ["ask", "240p", "360p", "480p", "720p", "1080p"]

MODE_LIST_SHOWS = 1
MODE_VIDEOLINK = 10

def getLS(strid):
    return addon.getLocalizedString(strid)

def notify(msg, timeout = 7000):
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(scriptname, msg.encode('utf-8'), timeout, addon.getAddonInfo('icon')))
    log(msg, xbmc.LOGINFO)

def log(msg, level=xbmc.LOGDEBUG):
    if type(msg).__name__ == 'unicode':
        msg = msg.encode('utf-8')
    xbmc.log("[%s] %s" % (scriptname, msg.__str__()), level)

def logDbg(msg):
    log(msg,level=xbmc.LOGDEBUG)

def logErr(msg):
    log(msg,level=xbmc.LOGERROR)

def getJsonData(var):
    headers = {'Content-type': 'application/json', 'Accept': 'application/json', 'User-Agent': _UserAgent_}
    req = urllib2.Request(__apiurl__, json.dumps(var).encode('utf-8'), headers)
    
    try:
        response = urllib2.urlopen(req)
        return json.loads(response.read().decode('utf-8'))
    except urllib2.HTTPError, e:
        logDbg(e.read())
    finally:
        response.close()

def listContent():
    data = getJsonData({"query":"query LoadChildTags($id : ID, $childTagsConnectionFirst : Int, $childTagsConnectionCategories : [Category]){ tag(id: $id){ childTagsConnection(categories: $childTagsConnectionCategories,first : $childTagsConnectionFirst) { ...TagCardsFragmentOnTagConnection  } } }\n\t\tfragment TagCardsFragmentOnTagConnection on TagConnection {\n\t\t\ttotalCount\n\t\t\tpageInfo {\n\t\t\t\tendCursor\n\t\t\t\thasNextPage\n\t\t\t}\n\t\t\tedges {\n\t\t\t\tnode {\n\t\t\t\t\t...TagCardFragmentOnTag\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t\n\t\tfragment TagCardFragmentOnTag on Tag {\n\t\t\tid,\n\t\t\tdotId,\n\t\t\tname,\n\t\t\tcategory,\n\t\t\tperex,\n\t\t\turlName,\n\t\t\timages {\n\t\t\t\t...DefaultFragmentOnImage\n\t\t\t},\n\t\t\toriginTag {\n\t\t\t\t...DefaultOriginTagFragmentOnTag\n\t\t\t}\n\t\t}\n\t\n\t\tfragment DefaultFragmentOnImage on Image {\n\t\t\tusage,\n\t\t\turl\n\t\t}\n\t\n\t\tfragment DefaultOriginTagFragmentOnTag on Tag {\n\t\t\tid,\n\t\t\tdotId,\n\t\t\tname,\n\t\t\turlName,\n\t\t\tcategory,\n\t\t\timages {\n\t\t\t\t...DefaultFragmentOnImage\n\t\t\t}\n\t\t}\n\t","variables":{"id":"VGFnOjI","childTagsConnectionFirst":300,"childTagsConnectionCategories":["show","tag"]}})
    for item in data[u'data'][u'tag'][u'childTagsConnection'][u'edges']:
        link = item[u'node'][u'urlName']
        for images in item[u'node'][u'images']:
            image = 'https:'+images[u'url']
        name = item[u'node'][u'name']
        perex = item[u'node'][u'perex']
        addDir(name, link, MODE_LIST_SHOWS, image, perex)

def listShows(url):
    data = getJsonData({"query":"query LoadTag($urlName : String, $episodesConnectionFirst : Int){ tagData:tag(urlName: $urlName, category: show){ ...ShowDetailFragmentOnTag episodesConnection(first : $episodesConnectionFirst) { ...SeasonEpisodeCardsFragmentOnEpisodeItemConnection } } }\n\t\tfragment ShowDetailFragmentOnTag on Tag {\n\t\t\tid\n\t\t\tdotId\n\t\t\tname\n\t\t\tcategory\n\t\t\turlName\n\t\t\tfavouritesCount\n\t\t\tperex\n\t\t\timages {\n\t\t\t\t...DefaultFragmentOnImage\n\t\t\t}\n\t\t\tbannerAdvert {\n\t\t\t\t...DefaultFragmentOnBannerAdvert\n\t\t\t},\n\t\t\toriginServiceTag {\n\t\t\t\t...OriginServiceTagFragmentOnTag\n\t\t\t}\n\t\t}\t\n\t\n\t\tfragment SeasonEpisodeCardsFragmentOnEpisodeItemConnection on EpisodeItemConnection {\n\t\t\ttotalCount\n\t\t\tpageInfo {\n\t\t\t\tendCursor\n\t\t\t\thasNextPage\n\t\t\t}\n\t\t\tedges {\n\t\t\t\tnode {\n\t\t\t\t\t...SeasonEpisodeCardFragmentOnEpisode\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t\n\t\tfragment DefaultFragmentOnImage on Image {\n\t\t\tusage,\n\t\t\turl\n\t\t}\n\t\n\t\tfragment DefaultFragmentOnBannerAdvert on BannerAdvert {\n\t\t\tsection\n\t\t}\n\t\n\t\tfragment OriginServiceTagFragmentOnTag on Tag {\n\t\t\tid,\n\t\t\tdotId,\n\t\t\tname,\n\t\t\turlName,\n\t\t\tcategory,\n\t\t\tinvisible,\n\t\t\timages {\n\t\t\t\t...DefaultFragmentOnImage\n\t\t\t}\n\t\t}\n\t\n\t\tfragment SeasonEpisodeCardFragmentOnEpisode on Episode {\n\t\t\tid\n\t\t\tdotId\n\t\t\tname\n\t\t\tnamePrefix\n\t\t\tduration\n\t\t\timages {\n\t\t\t\t...DefaultFragmentOnImage\n\t\t\t}\n\t\t\turlName\n\t\t\toriginTag {\n\t\t\t\t...DefaultOriginTagFragmentOnTag\n\t\t\t}\n\t\t\tpublish\n\t\t\tviews\n\t\t}\n\t\n\t\tfragment DefaultOriginTagFragmentOnTag on Tag {\n\t\t\tid,\n\t\t\tdotId,\n\t\t\tname,\n\t\t\turlName,\n\t\t\tcategory,\n\t\t\timages {\n\t\t\t\t...DefaultFragmentOnImage\n\t\t\t}\n\t\t}\n\t","variables":{"urlName":""+url+"","episodesConnectionFirst":100}})
    
    for item in data[u'data'][u'tagData'][u'episodesConnection'][u'edges']:
        link = item[u'node'][u'urlName']
        image = 'https:'+item[u'node'][u'images'][0][u'url']
        name = item[u'node'][u'name']
        date = datetime.utcfromtimestamp(item[u'node'][u'publish']).strftime("%Y-%m-%d")
        logDbg(date)
        info={'duration':item[u'node'][u'duration'],'date':date}
        addResolvedLink(name, link, image, name, info=info)

def videoLink(url):
    data = getJsonData({"query":"query LoadEpisode($urlName : String){ episode(urlName: $urlName){ ...VideoDetailFragmentOnEpisode } }\n\t\tfragment VideoDetailFragmentOnEpisode on Episode {\n\t\t\tid\n\t\t\tdotId\n\t\t\tdotOriginalService\n\t\t\toriginalId\n\t\t\tname\n\t\t\tperex\n\t\t\tduration\n\t\t\timages {\n\t\t\t\t...DefaultFragmentOnImage\n\t\t\t}\n\t\t\tspl\n\t\t\tcommentsDisabled\n\t\t\tproductPlacement\n\t\t\turlName\n\t\t\toriginUrl\n\t\t\toriginTag {\n\t\t\t\t...OriginTagInfoFragmentOnTag\n\t\t\t}\n\t\t\tadvertEnabled\n\t\t\tadverts {\n\t\t\t\t...DefaultFragmentOnAdvert\n\t\t\t}\n\t\t\tbannerAdvert {\n\t\t\t\t...DefaultFragmentOnBannerAdvert\n\t\t\t}\n\t\t\tviews\n\t\t\tpublish\n\t\t\tlinks {\n\t\t\t\t...DefaultFragmentOnLinks\n\t\t\t}\n\t\t\trecommendedAbVariant\n\t\t\tsklikRetargeting\n\t\t}\n\t\n\t\tfragment DefaultFragmentOnImage on Image {\n\t\t\tusage,\n\t\t\turl\n\t\t}\n\t\n\t\tfragment OriginTagInfoFragmentOnTag on Tag {\n\t\t\tid,\n\t\t\tdotId,\n\t\t\tname,\n\t\t\turlName,\n\t\t\tcategory,\n\t\t\tinvisible,\n\t\t\timages {\n\t\t\t\t...DefaultFragmentOnImage\n\t\t\t}\n\t\t}\n\t\n\t\tfragment DefaultFragmentOnAdvert on Advert {\n\t\t\tzoneId\n\t\t\tsection\n\t\t\tcollocation\n\t\t\tposition\n\t\t\trollType\n\t\t}\n\t\n\t\tfragment DefaultFragmentOnBannerAdvert on BannerAdvert {\n\t\t\tsection\n\t\t}\n\t\n\t\tfragment DefaultFragmentOnLinks on Link {\n\t\t\tlabel,\n\t\t\turl\n\t\t}\n\t","variables":{"urlName":""+url+""}})
    name = data[u'data'][u'episode'][u'name']
    image = 'https:'+data[u'data'][u'episode'][u'images'][0][u'url']
    perex = data[u'data'][u'episode'][u'perex']
    link = data[u'data'][u'episode'][u'spl'].split('/')
    
    req = urllib2.Request(data[u'data'][u'episode'][u'spl']+'spl2,3', None, {'Content-type': 'application/json', 'Accept': 'application/json', 'User-Agent': _UserAgent_})
    resp = urllib2.urlopen(req)
    content = json.loads(resp.read().decode('utf-8'))

    stream_url = link[0]+'/'+link[1]+'/'+link[2]+'/'+link[3]+'/'+link[4]+'/'+content[u'data'][u"mp4"][u"1080p"][u"url"][3:]
    
    liz = xbmcgui.ListItem()
    liz = xbmcgui.ListItem(path=stream_url)  
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": perex})
    liz.setProperty('isPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle=addonHandle, succeeded=True, listitem=liz)

def getParams():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

def composePluginUrl(url, mode, name, plot):
    return sys.argv[0]+"?url="+urllib.quote_plus(url.encode('utf-8'))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name.encode('utf-8'))+'&plot='+urllib.quote_plus(plot.encode('utf-8'))

def addItem(name, url, mode, iconimage, desc, isfolder, islatest=False, info={}):
    u = composePluginUrl(url, mode, name, desc)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, 'plot': desc})
    liz.setProperty( "Fanart_Image", fanart )
    if u'date' in info:
        liz.setInfo('video', {'mediatype': 'episode', 'title': name, 'plot': desc, 'premiered': info[u'date']})
    if u'duration' in info:
        liz.addStreamInfo('video', {'duration': info[u'duration']})
    if not isfolder:
        liz.setProperty("IsPlayable", "true")
    ok=xbmcplugin.addDirectoryItem(handle=addonHandle,url=u,listitem=liz,isFolder=isfolder)
    return ok

def addDir(name, url, mode, iconimage, plot='', info={}):
    logDbg("addDir(): '"+name+"' url='"+url+"' icon='"+iconimage+"' mode='"+str(mode)+"'")
    return addItem(name, url, mode, iconimage, plot, True)
    
def addResolvedLink(name, url, iconimage, plot='', islatest=False, info={}):
    mode = MODE_VIDEOLINK
    logDbg("addUnresolvedLink(): '"+name+"' url='"+url+"' icon='"+iconimage+"' mode='"+str(mode)+"'")
    return addItem(name, url, mode, iconimage, plot, False, islatest, info)

addonHandle=int(sys.argv[1])
params=getParams()
url = None
name = None
thumb = None
mode = None
plot = ''

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    plot = urllib.unquote_plus(params["plot"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

logDbg("Mode: "+str(mode))
logDbg("URL: "+str(url))
logDbg("Name: "+str(name))

if mode==None or url==None or len(url)<1:
    logDbg('listContent()')
    listContent()
   
elif mode==MODE_LIST_SHOWS:
    logDbg('listShows() with url ' + str(url))
    listShows(url)
    
elif mode==MODE_VIDEOLINK:
    logDbg('videoLink() with url ' + str(url))
    videoLink(url)
    
xbmcplugin.endOfDirectory(addonHandle)
