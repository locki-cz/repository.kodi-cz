# plugin.video.mall.tv

Video dopln�k do [kodi](http://www.kodi.tv/) pro p�ehr�v�n� vide� z internehov� televize [mall.tv](https://www.mall.tv/).

Informace o instalaci najdete na str�nk�ch repozit��e [Kodi CZ/SK](http://kodi-czsk.github.io/repository/).
