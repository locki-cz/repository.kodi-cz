### Prima Play Kodi Addon

[![Build Status](https://travis-ci.org/alladdin/plugin.video.primaplay.svg?branch=master)](https://travis-ci.org/alladdin/plugin.video.primaplay)

Doplněk pro přehrávání videí z archivu iPrima
