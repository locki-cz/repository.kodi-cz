# plugin.video.seznam-zpravy

Video doplněk do [kodi](http://www.kodi.tv/) pro přehrávání videí z [Seznam zpravy](https://www.seznam.cz/zpravy).

Informace o instalaci najdete na stránkách repozitáře [Kodi CZ/SK](http://kodi-czsk.github.io/repository/).
